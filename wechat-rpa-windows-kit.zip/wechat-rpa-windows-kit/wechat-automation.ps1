param(
  [Parameter(ValueFromRemainingArguments = $true)]
  [string[]]$RestArgs
)

$ErrorActionPreference = 'Stop'
$Utf8NoBom = New-Object System.Text.UTF8Encoding($false)
[Console]::OutputEncoding = $Utf8NoBom
$OutputEncoding = $Utf8NoBom

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
try {
  Add-Type -AssemblyName UIAutomationClient
  Add-Type -AssemblyName UIAutomationTypes
} catch {
  # UIAutomation is available on normal Windows desktops. Keep the helper usable
  # in reduced runtimes and fall back to coordinate candidates.
}
Add-Type @"
using System;
using System.Text;
using System.Runtime.InteropServices;

public delegate bool MaoEnumWindowsProc(IntPtr hWnd, IntPtr lParam);

public static class MaoWin32 {
  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
  [DllImport("user32.dll")] public static extern bool SetForegroundWindow(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);
  [DllImport("user32.dll")] public static extern bool BringWindowToTop(IntPtr hWnd);
  [DllImport("user32.dll")] public static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);
  [DllImport("user32.dll")] public static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool fAttach);
  [DllImport("user32.dll")] public static extern IntPtr SetActiveWindow(IntPtr hWnd);
  [DllImport("kernel32.dll")] public static extern uint GetCurrentThreadId();
  [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);
  [DllImport("user32.dll")] public static extern bool EnumWindows(MaoEnumWindowsProc lpEnumFunc, IntPtr lParam);
  [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr hWnd);
  [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
  public static extern int GetWindowText(IntPtr hWnd, StringBuilder lpString, int nMaxCount);
  [DllImport("user32.dll")] public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);
  [DllImport("user32.dll")] public static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, UIntPtr dwExtraInfo);

  [StructLayout(LayoutKind.Sequential)]
  public struct RECT {
    public int Left;
    public int Top;
    public int Right;
    public int Bottom;
  }
}
"@

try {
  [MaoWin32]::SetProcessDPIAware() | Out-Null
} catch {}

$LogDir = if ($env:MAO_LOG_DIR) { $env:MAO_LOG_DIR } else { Join-Path ([Environment]::GetFolderPath('LocalApplicationData')) 'DuoduoDigitalManager\logs' }
New-Item -ItemType Directory -Path $LogDir -Force | Out-Null
$LogPath = Join-Path $LogDir ("wechat-desktop-automation-{0}.log" -f (Get-Date -Format 'yyyy-MM-dd'))
$script:ActiveWeChatProcess = $null
$script:ActiveWeChatHandle = [IntPtr]::Zero
$script:SW_RESTORE = 9
$script:SWP_NOSIZE = 0x0001
$script:SWP_NOMOVE = 0x0002
$script:SWP_SHOWWINDOW = 0x0040
$script:HWND_TOPMOST = [IntPtr](-1)
$script:HWND_NOTOPMOST = [IntPtr](-2)
$script:VK_MENU = 0x12
$script:KEYEVENTF_KEYUP = 0x0002

function Write-AutoLog {
  param([string]$Message)
  $line = "[{0}] {1}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss.fff'), $Message
  Add-Content -Path $LogPath -Value $line -Encoding UTF8
}

trap {
  Write-AutoLog "fatal error: $($_.Exception.Message)"
  if ($_.ScriptStackTrace) {
    Write-AutoLog "fatal stack: $($_.ScriptStackTrace)"
  }
  throw
}

function Emit-Json {
  param([hashtable]$Payload)
  $Payload | ConvertTo-Json -Compress -Depth 8
}

function Parse-Options {
  $options = @{
    Room = ''
    Text = ''
    Mentions = New-Object System.Collections.Generic.List[string]
    Images = New-Object System.Collections.Generic.List[string]
    Send = $false
    CheckPermission = $false
    KeyboardTest = $false
    KeyboardEnterTest = $false
    OpenRetryTest = $false
    PressReturnOnly = $false
    SelectMethod = 'click-first'
  }

  foreach ($arg in $RestArgs) {
    if ($arg -eq '--send') {
      $options.Send = $true
    } elseif ($arg -eq '--dry-run' -or $arg -eq '--no-send') {
      $options.Send = $false
    } elseif ($arg -eq '--check-permission') {
      $options.CheckPermission = $true
    } elseif ($arg -eq '--keyboard-test') {
      $options.KeyboardTest = $true
    } elseif ($arg -eq '--keyboard-enter-test') {
      $options.KeyboardEnterTest = $true
    } elseif ($arg -eq '--open-retry-test') {
      $options.OpenRetryTest = $true
    } elseif ($arg -eq '--press-return-only') {
      $options.PressReturnOnly = $true
    } elseif ($arg.StartsWith('--room=')) {
      $options.Room = $arg.Substring('--room='.Length).Trim()
    } elseif ($arg.StartsWith('--text=')) {
      $options.Text = $arg.Substring('--text='.Length)
    } elseif ($arg.StartsWith('--mention=')) {
      $name = $arg.Substring('--mention='.Length).Trim()
      if ($name) { $options.Mentions.Add($name) }
    } elseif ($arg.StartsWith('--mentions=')) {
      $names = $arg.Substring('--mentions='.Length) -split '[,\uFF0C]'
      foreach ($name in $names) {
        $trimmed = $name.Trim()
        if ($trimmed) { $options.Mentions.Add($trimmed) }
      }
    } elseif ($arg.StartsWith('--image=')) {
      $image = $arg.Substring('--image='.Length).Trim()
      if ($image) { $options.Images.Add($image) }
    } elseif ($arg.StartsWith('--images=')) {
      $images = $arg.Substring('--images='.Length) -split "`n"
      foreach ($image in $images) {
        $trimmed = $image.Trim()
        if ($trimmed) { $options.Images.Add($trimmed) }
      }
    } elseif ($arg.StartsWith('--select-method=')) {
      $options.SelectMethod = $arg.Substring('--select-method='.Length).Trim()
    }
  }

  return $options
}

function Test-WeChatDesktopProcess {
  param([System.Diagnostics.Process]$Process)
  if (-not $Process) { return $false }
  return (($Process.ProcessName -as [string]) -match '^(WeChat|Weixin|WeChatAppEx)$')
}

function Get-WindowTitle {
  param([IntPtr]$Handle)
  $builder = New-Object System.Text.StringBuilder 512
  [MaoWin32]::GetWindowText($Handle, $builder, $builder.Capacity) | Out-Null
  return $builder.ToString()
}

function Get-WeChatTopLevelWindows {
  $items = New-Object System.Collections.Generic.List[object]
  $callback = [MaoEnumWindowsProc]{
    param([IntPtr]$Handle, [IntPtr]$Param)
    try {
      $pidValue = [uint32]0
      [MaoWin32]::GetWindowThreadProcessId($Handle, [ref]$pidValue) | Out-Null
      if ($pidValue -eq 0) { return $true }
      $process = $null
      try { $process = Get-Process -Id ([int]$pidValue) -ErrorAction Stop } catch { return $true }
      if (-not (Test-WeChatDesktopProcess -Process $process)) { return $true }
      $rect = New-Object MaoWin32+RECT
      if (-not [MaoWin32]::GetWindowRect($Handle, [ref]$rect)) { return $true }
      $width = [int]($rect.Right - $rect.Left)
      $height = [int]($rect.Bottom - $rect.Top)
      if ($width -le 0 -or $height -le 0) { return $true }
      $visible = [MaoWin32]::IsWindowVisible($Handle)
      $area = [double]($width * $height)
      $score = $area
      if ($visible) { $score += 1000000000.0 }
      $items.Add([pscustomobject]@{
        Handle = $Handle
        Process = $process
        ProcessId = [int]$pidValue
        ProcessName = $process.ProcessName
        Title = Get-WindowTitle -Handle $Handle
        Visible = [bool]$visible
        Left = [int]$rect.Left
        Top = [int]$rect.Top
        Width = $width
        Height = $height
        Score = $score
      })
    } catch {}
    return $true
  }
  [MaoWin32]::EnumWindows($callback, [IntPtr]::Zero) | Out-Null
  return $items
}

function Test-WeChatMainWindowCandidate {
  param([object]$Window)
  if (-not $Window) { return $false }
  if (-not [bool]$Window.Visible) { return $false }
  if ([int]$Window.Width -lt 450) { return $false }
  if ([int]$Window.Height -lt 360) { return $false }
  return $true
}

function Assert-SingleWeChatMainWindow {
  param([object[]]$Windows, [string]$Context)
  $mainWindows = @($Windows | Where-Object { Test-WeChatMainWindowCandidate -Window $_ })
  if ($mainWindows.Count -le 1) { return $mainWindows }
  foreach ($item in @($mainWindows | Sort-Object @{ Expression = 'Score'; Descending = $true })) {
    Write-AutoLog "multiple WeChat main window candidate context=$Context pid=$($item.ProcessId) process=$($item.ProcessName) title=$($item.Title) handle=$($item.Handle) rect=$($item.Left),$($item.Top),$($item.Width)x$($item.Height)"
  }
  $allowMultiple = ([string]$env:MAO_ALLOW_MULTIPLE_WECHAT_WINDOWS).ToLowerInvariant() -eq 'true'
  if ($allowMultiple) {
    Write-AutoLog "multiple WeChat main windows allowed by MAO_ALLOW_MULTIPLE_WECHAT_WINDOWS=true context=$Context count=$($mainWindows.Count)"
    return $mainWindows
  }
  throw "Multiple WeChat main windows detected ($($mainWindows.Count)). Close duplicate WeChat/chat windows before running RPA."
}

function Find-WeChatTopLevelWindow {
  param([int]$ProcessId = 0)
  $windows = @(Get-WeChatTopLevelWindows)
  if ($ProcessId -gt 0) {
    $windows = @($windows | Where-Object { $_.ProcessId -eq $ProcessId })
  }
  if ($windows.Count -gt 0) {
    foreach ($item in @($windows | Sort-Object @{ Expression = 'Score'; Descending = $true } | Select-Object -First 6)) {
      Write-AutoLog "found WeChat top-level window pid=$($item.ProcessId) process=$($item.ProcessName) visible=$($item.Visible) title=$($item.Title) handle=$($item.Handle) rect=$($item.Left),$($item.Top),$($item.Width)x$($item.Height)"
    }
    $mainWindows = Assert-SingleWeChatMainWindow -Windows $windows -Context "processId=$ProcessId"
    if ($mainWindows.Count -gt 0) {
      return @($mainWindows | Sort-Object @{ Expression = 'Score'; Descending = $true } | Select-Object -First 1)[0]
    }
    return @($windows | Sort-Object @{ Expression = 'Score'; Descending = $true } | Select-Object -First 1)[0]
  }
  Write-AutoLog "no WeChat top-level windows found processId=$ProcessId"
  return $null
}

function Get-WeChatMainWindowHandle {
  param([System.Diagnostics.Process]$Process)
  if (-not $Process) { return [IntPtr]::Zero }
  if ($script:ActiveWeChatProcess -and $script:ActiveWeChatProcess.Id -eq $Process.Id -and $script:ActiveWeChatHandle -ne [IntPtr]::Zero) {
    return $script:ActiveWeChatHandle
  }
  try { $Process.Refresh() } catch {}
  if ($Process.MainWindowHandle -ne [IntPtr]::Zero) {
    $script:ActiveWeChatProcess = $Process
    $script:ActiveWeChatHandle = $Process.MainWindowHandle
    return $Process.MainWindowHandle
  }
  $window = Find-WeChatTopLevelWindow -ProcessId $Process.Id
  if ($window) {
    $script:ActiveWeChatProcess = $window.Process
    $script:ActiveWeChatHandle = $window.Handle
    return $window.Handle
  }
  return [IntPtr]::Zero
}

function Find-WeChatProcess {
  $window = Find-WeChatTopLevelWindow
  if ($window) {
    $script:ActiveWeChatProcess = $window.Process
    $script:ActiveWeChatHandle = $window.Handle
    return $window.Process
  }

  $running = @(Get-Process -ErrorAction SilentlyContinue |
    Where-Object { Test-WeChatDesktopProcess -Process $_ })

  if ($running.Count -gt 0) {
    foreach ($item in @($running | Select-Object -First 6)) {
      Write-AutoLog "found WeChat process without top-level window pid=$($item.Id) process=$($item.ProcessName) title=$($item.MainWindowTitle) handle=$($item.MainWindowHandle)"
    }
    try {
      $shell = New-Object -ComObject WScript.Shell
      foreach ($item in @($running | Select-Object -First 3)) {
        $shell.AppActivate($item.Id) | Out-Null
        Start-Sleep -Milliseconds 400
        $window = Find-WeChatTopLevelWindow -ProcessId $item.Id
        if ($window) {
          $script:ActiveWeChatProcess = $window.Process
          $script:ActiveWeChatHandle = $window.Handle
          return $window.Process
        }
      }
    } catch {}
    Write-AutoLog 'WeChat process exists but no top-level window was found; skip starting duplicate instance'
    return $running[0]
  }

  function Join-OptionalPath {
    param([string]$Base, [string]$Child)
    if ([string]::IsNullOrWhiteSpace($Base)) { return $null }
    return Join-Path $Base $Child
  }

  function Get-AppPathFromRegistry {
    param([string]$Key)
    try {
      $output = & reg.exe query $Key /ve 2>$null
      foreach ($line in $output) {
        if ($line -match 'REG_\w+\s+(.+?)\s*$') {
          return $Matches[1].Trim()
        }
      }
    } catch {}
    return $null
  }

  function Expand-WeChatExecutableCandidate {
    param([string]$Path)
    $items = New-Object System.Collections.Generic.List[string]
    if ([string]::IsNullOrWhiteSpace($Path)) { return $items }
    $clean = $Path.Trim().Trim('"')
    if (-not [string]::IsNullOrWhiteSpace($clean)) {
      $items.Add($clean)
      if ([IO.Path]::GetFileName($clean) -ieq 'Wexin.exe') {
        $directory = [IO.Path]::GetDirectoryName($clean)
        if ($directory) {
          $items.Add((Join-Path $directory 'Weixin.exe'))
        }
      }
    }
    return $items.ToArray()
  }

  $rawCandidates = @(
    ${env:MAO_WECHAT_EXE_PATH},
    (Join-OptionalPath ${env:ProgramFiles} 'Tencent\Weixin\Weixin.exe'),
    (Join-OptionalPath ${env:ProgramFiles} 'Tencent\WeChat\WeChat.exe'),
    (Join-OptionalPath ${env:ProgramFiles(x86)} 'Tencent\Weixin\Weixin.exe'),
    (Join-OptionalPath ${env:ProgramFiles(x86)} 'Tencent\WeChat\WeChat.exe'),
    (Join-OptionalPath ${env:LOCALAPPDATA} 'Tencent\Weixin\Weixin.exe'),
    (Join-OptionalPath ${env:LOCALAPPDATA} 'Tencent\WeChat\WeChat.exe'),
    (Join-OptionalPath ${env:LOCALAPPDATA} 'Programs\Tencent\Weixin\Weixin.exe'),
    (Join-OptionalPath ${env:LOCALAPPDATA} 'Programs\Tencent\WeChat\WeChat.exe'),
    (Join-OptionalPath ${env:LOCALAPPDATA} 'Microsoft\WindowsApps\Weixin.exe'),
    (Join-OptionalPath ${env:LOCALAPPDATA} 'Microsoft\WindowsApps\WeChat.exe'),
    (Get-AppPathFromRegistry 'HKCU\Software\Microsoft\Windows\CurrentVersion\App Paths\Weixin.exe'),
    (Get-AppPathFromRegistry 'HKCU\Software\Microsoft\Windows\CurrentVersion\App Paths\WeChat.exe'),
    (Get-AppPathFromRegistry 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\Weixin.exe'),
    (Get-AppPathFromRegistry 'HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\WeChat.exe'),
    (Get-AppPathFromRegistry 'HKLM\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\Weixin.exe'),
    (Get-AppPathFromRegistry 'HKLM\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\WeChat.exe'),
    ((Get-Command Weixin.exe -ErrorAction SilentlyContinue | Select-Object -First 1).Source),
    ((Get-Command WeChat.exe -ErrorAction SilentlyContinue | Select-Object -First 1).Source)
  )

  $candidates = @($rawCandidates |
    ForEach-Object { Expand-WeChatExecutableCandidate $_ } |
    Where-Object { $_ -and (Test-Path $_) } |
    Select-Object -Unique)

  Write-AutoLog "WeChat process not running; executable candidates count=$($candidates.Count)"
  if ($candidates.Count -gt 0) {
    Write-AutoLog "starting WeChat from $($candidates[0])"
    Start-Process -FilePath $candidates[0] | Out-Null
    for ($i = 0; $i -lt 20; $i += 1) {
      Start-Sleep -Milliseconds 500
      $window = Find-WeChatTopLevelWindow
      if ($window) {
        $script:ActiveWeChatProcess = $window.Process
        $script:ActiveWeChatHandle = $window.Handle
        return $window.Process
      }
    }
    Write-AutoLog 'started WeChat executable but no main window was detected after waiting'
  } else {
    Write-AutoLog 'no WeChat executable candidate found'
  }

  return $null
}

function Get-WindowRect {
  param([IntPtr]$Handle)
  $rect = New-Object MaoWin32+RECT
  if (-not [MaoWin32]::GetWindowRect($Handle, [ref]$rect)) {
    throw 'Cannot read WeChat window bounds.'
  }
  return @{
    Left = $rect.Left
    Top = $rect.Top
    Right = $rect.Right
    Bottom = $rect.Bottom
    Width = $rect.Right - $rect.Left
    Height = $rect.Bottom - $rect.Top
  }
}

function Get-ForegroundWindowInfo {
  $handle = [MaoWin32]::GetForegroundWindow()
  $pidValue = [uint32]0
  [MaoWin32]::GetWindowThreadProcessId($handle, [ref]$pidValue) | Out-Null
  $name = ''
  $title = ''
  try {
    $foregroundProcess = Get-Process -Id ([int]$pidValue) -ErrorAction Stop
    $name = $foregroundProcess.ProcessName
    $title = $foregroundProcess.MainWindowTitle
  } catch {}
  return @{
    Handle = $handle
    ProcessId = [int]$pidValue
    ProcessName = $name
    Title = $title
  }
}

function Format-ForegroundInfo {
  param([hashtable]$Info)
  if (-not $Info) { return 'none' }
  $title = (($Info.Title -as [string]) -replace '\s+', ' ').Trim()
  if ($title.Length -gt 48) { $title = $title.Substring(0, 48) + '...' }
  return "pid=$($Info.ProcessId) process=$($Info.ProcessName) title=$title"
}

function Test-WeChatForeground {
  param([System.Diagnostics.Process]$Process)
  if (-not $Process) { return $false }
  $info = Get-ForegroundWindowInfo
  if ($info.ProcessId -eq $Process.Id) {
    $script:ActiveWeChatHandle = $info.Handle
    return $true
  }
  if (($info.ProcessName -as [string]) -match '^(WeChat|Weixin|WeChatAppEx)$') {
    $script:ActiveWeChatHandle = $info.Handle
    return $true
  }
  return $false
}

function Invoke-AltPulse {
  [MaoWin32]::keybd_event([byte]$script:VK_MENU, 0, 0, [UIntPtr]::Zero)
  Start-Sleep -Milliseconds 40
  [MaoWin32]::keybd_event([byte]$script:VK_MENU, 0, [uint32]$script:KEYEVENTF_KEYUP, [UIntPtr]::Zero)
  Start-Sleep -Milliseconds 40
}

function Invoke-WeChatForeground {
  param([System.Diagnostics.Process]$Process, [string]$Reason = 'activate')
  if (-not $Process) {
    $Process = Find-WeChatProcess
    if (-not $Process) { return $false }
  }
  try { $Process.Refresh() } catch {}
  $handle = Get-WeChatMainWindowHandle -Process $Process
  if ($handle -eq [IntPtr]::Zero) {
    Write-AutoLog "foreground reacquire needed reason=$Reason because handle is zero pid=$($Process.Id)"
    $Process = Find-WeChatProcess
    if (-not $Process) { return $false }
    try { $Process.Refresh() } catch {}
    $handle = Get-WeChatMainWindowHandle -Process $Process
    if ($handle -eq [IntPtr]::Zero) { return $false }
  }
  $script:ActiveWeChatProcess = $Process
  $script:ActiveWeChatHandle = $handle
  $flags = [uint32]($script:SWP_NOMOVE -bor $script:SWP_NOSIZE -bor $script:SWP_SHOWWINDOW)
  for ($attempt = 1; $attempt -le 5; $attempt += 1) {
    $foregroundHandle = [MaoWin32]::GetForegroundWindow()
    $foregroundPid = [uint32]0
    $targetPid = [uint32]0
    $foregroundThread = [MaoWin32]::GetWindowThreadProcessId($foregroundHandle, [ref]$foregroundPid)
    $targetThread = [MaoWin32]::GetWindowThreadProcessId($handle, [ref]$targetPid)
    $currentThread = [MaoWin32]::GetCurrentThreadId()
    $attachedForeground = $false
    $attachedTarget = $false
    if ($foregroundThread -ne 0 -and $foregroundThread -ne $currentThread) {
      $attachedForeground = [MaoWin32]::AttachThreadInput($currentThread, $foregroundThread, $true)
    }
    if ($targetThread -ne 0 -and $targetThread -ne $currentThread) {
      $attachedTarget = [MaoWin32]::AttachThreadInput($currentThread, $targetThread, $true)
    }
    [MaoWin32]::ShowWindowAsync($handle, $script:SW_RESTORE) | Out-Null
    Start-Sleep -Milliseconds 100
    try {
      $shell = New-Object -ComObject WScript.Shell
      $shell.AppActivate($Process.Id) | Out-Null
    } catch {}
    [MaoWin32]::BringWindowToTop($handle) | Out-Null
    [MaoWin32]::SetWindowPos($handle, $script:HWND_TOPMOST, 0, 0, 0, 0, $flags) | Out-Null
    [MaoWin32]::SetWindowPos($handle, $script:HWND_NOTOPMOST, 0, 0, 0, 0, $flags) | Out-Null
    Invoke-AltPulse
    $setResult = [MaoWin32]::SetForegroundWindow($handle)
    [MaoWin32]::SetActiveWindow($handle) | Out-Null
    if ($attachedTarget) {
      [MaoWin32]::AttachThreadInput($currentThread, $targetThread, $false) | Out-Null
    }
    if ($attachedForeground) {
      [MaoWin32]::AttachThreadInput($currentThread, $foregroundThread, $false) | Out-Null
    }
    Start-Sleep -Milliseconds (220 + ($attempt * 80))
    if (Test-WeChatForeground -Process $Process) {
      Write-AutoLog "foreground verified reason=$Reason attempt=$attempt pid=$($Process.Id)"
      return $true
    }
    $foreground = Format-ForegroundInfo (Get-ForegroundWindowInfo)
    Write-AutoLog "foreground attempt failed reason=$Reason attempt=$attempt setResult=$setResult attachedForeground=$attachedForeground attachedTarget=$attachedTarget foreground=$foreground"
  }
  return $false
}

function Assert-WeChatForeground {
  param([System.Diagnostics.Process]$Process = $script:ActiveWeChatProcess, [string]$Context = 'operation')
  if (-not $Process) {
    $Process = Find-WeChatProcess
    if (-not $Process) { return }
  }
  if (Test-WeChatForeground -Process $Process) { return }
  $foregroundBefore = Format-ForegroundInfo (Get-ForegroundWindowInfo)
  Write-AutoLog "foreground lost before $Context; foreground=$foregroundBefore; trying recovery"
  if (Invoke-WeChatForeground -Process $Process -Reason "assert-$Context") {
    Write-AutoLog "foreground recovered before $Context"
    return
  }
  if (Test-WeChatForeground -Process $Process) { return }
  $fresh = Find-WeChatProcess
  if ($fresh -and (Invoke-WeChatForeground -Process $fresh -Reason "assert-$Context-fresh")) {
    Write-AutoLog "foreground recovered before $Context using fresh process pid=$($fresh.Id)"
    return
  }
  $foreground = Format-ForegroundInfo (Get-ForegroundWindowInfo)
  throw "WeChat is not foreground before $Context; foreground=$foreground. Stop to avoid operating the wrong app."
}

function Send-WeChatKeys {
  param([string]$Keys, [string]$Context, [int]$AfterDelayMs = 0)
  Assert-WeChatForeground -Context "sendkeys-$Context"
  $foreground = Format-ForegroundInfo (Get-ForegroundWindowInfo)
  Write-AutoLog "send keys context=$Context keys=$Keys foreground=$foreground"
  [System.Windows.Forms.SendKeys]::SendWait($Keys)
  if ($AfterDelayMs -gt 0) {
    Start-Sleep -Milliseconds $AfterDelayMs
  }
}

function Activate-WeChat {
  $process = Find-WeChatProcess
  if (-not $process) {
    throw 'WeChat window was not found. Please open and log in to desktop WeChat.'
  }
  $handle = Get-WeChatMainWindowHandle -Process $process
  if ($handle -eq [IntPtr]::Zero) {
    throw 'WeChat process was found, but no controllable top-level window was detected.'
  }
  if (-not (Invoke-WeChatForeground -Process $process -Reason 'activate')) {
    $foreground = Format-ForegroundInfo (Get-ForegroundWindowInfo)
    throw "Cannot bring WeChat to foreground; foreground=$foreground."
  }
  $handle = Get-WeChatMainWindowHandle -Process $process
  $rect = Get-WindowRect -Handle $handle
  $script:ActiveWeChatProcess = $process
  $script:ActiveWeChatHandle = $handle
  Write-AutoLog "activated WeChat pid=$($process.Id) process=$($process.ProcessName) title=$($process.MainWindowTitle) handle=$handle rect=$($rect.Left),$($rect.Top),$($rect.Width)x$($rect.Height)"
  return @{ Process = $process; Rect = $rect }
}

function Click-Point {
  param([int]$X, [int]$Y, [string]$Name)
  Assert-WeChatForeground -Context "click-$Name"
  $before = Format-ForegroundInfo (Get-ForegroundWindowInfo)
  Write-AutoLog "click prepare name=$Name point=$X,$Y foreground=$before"
  [System.Windows.Forms.Cursor]::Position = New-Object System.Drawing.Point($X, $Y)
  Start-Sleep -Milliseconds 80
  Assert-WeChatForeground -Context "click-$Name-before-down"
  [MaoWin32]::mouse_event(0x0002, 0, 0, 0, [UIntPtr]::Zero)
  [MaoWin32]::mouse_event(0x0004, 0, 0, 0, [UIntPtr]::Zero)
  $after = Format-ForegroundInfo (Get-ForegroundWindowInfo)
  Write-AutoLog "clicked $Name at $X,$Y foregroundAfter=$after"
  Start-Sleep -Milliseconds 220
}

function Set-ClipboardTextSafe {
  param([string]$Text)
  $textValue = $Text -as [string]
  if ($null -eq $textValue) { $textValue = '' }
  Write-AutoLog "set clipboard text length=$($textValue.Length)"
  [System.Windows.Forms.Clipboard]::SetText($Text)
  Start-Sleep -Milliseconds 80
}

function Set-ClipboardFilesSafe {
  param([string[]]$Paths)
  $collection = New-Object System.Collections.Specialized.StringCollection
  foreach ($path in $Paths) {
    if (Test-Path $path) {
      [void]$collection.Add((Resolve-Path $path).Path)
    } else {
      Write-AutoLog "image path missing: $path"
    }
  }
  if ($collection.Count -gt 0) {
    [System.Windows.Forms.Clipboard]::SetFileDropList($collection)
    Start-Sleep -Milliseconds 120
  }
  return $collection.Count
}

function Paste-Clipboard {
  Assert-WeChatForeground -Context 'paste'
  Send-WeChatKeys -Keys '^v' -Context 'paste' -AfterDelayMs 450
  Write-AutoLog 'sent Ctrl+V paste'
}

function Clear-Input {
  Assert-WeChatForeground -Context 'clear-input'
  Send-WeChatKeys -Keys '^a' -Context 'clear-input-select-all' -AfterDelayMs 80
  Send-WeChatKeys -Keys '{DEL}' -Context 'clear-input-delete' -AfterDelayMs 120
}

function Normalize-RoomText {
  param([string]$Value)
  if ($null -eq $Value) { return '' }
  return ($Value `
    -replace '\uFF5E','~' `
    -replace '\u301C','~' `
    -replace '\uFF0D','-' `
    -replace '\u2014','-' `
    -replace '\u2013','-' `
    -replace '\u2026','' `
    -replace '\u22EF','' `
    -replace '\|','' `
    -replace '\uFF5C','' `
    -replace '\u4E28','' `
    -replace '\uFF3B','' `
    -replace '\uFF3D','' `
    -replace '[\s\u00A0\u2005\u2006]+','')
}

function Get-LcsLength {
  param([char[]]$Left, [char[]]$Right)
  if ($Left.Count -eq 0 -or $Right.Count -eq 0) { return 0 }
  $previous = New-Object int[] ($Right.Count + 1)
  $current = New-Object int[] ($Right.Count + 1)
  foreach ($leftChar in $Left) {
    $current[0] = 0
    for ($i = 0; $i -lt $Right.Count; $i += 1) {
      if ($leftChar -eq $Right[$i]) {
        $current[$i + 1] = $previous[$i] + 1
      } else {
        $current[$i + 1] = [Math]::Max($previous[$i + 1], $current[$i])
      }
    }
    $tmp = $previous
    $previous = $current
    $current = $tmp
  }
  return $previous[$Right.Count]
}

function Get-RoomTextSimilarity {
  param([string]$Value, [string]$Room)
  $targetText = Normalize-RoomText $Room
  $normalizedText = Normalize-RoomText $Value
  if (-not $targetText -or -not $normalizedText) { return 0.0 }
  if ($targetText -eq $normalizedText) { return 1.0 }
  $target = [char[]]$targetText
  $normalized = [char[]]$normalizedText
  $longer = [Math]::Max($target.Count, $normalized.Count)
  if ($longer -le 4) { return 0.0 }
  $shorter = [Math]::Max(1, [Math]::Min($target.Count, $normalized.Count))
  $coverage = $shorter / [Math]::Max(1, $target.Count)
  if ($coverage -lt 0.5) { return 0.0 }
  $lcs = Get-LcsLength -Left $target -Right $normalized
  return $lcs / $shorter
}

function Test-RoomTextMatches {
  param([string]$Value, [string]$Room)
  $target = Normalize-RoomText $Room
  $normalized = Normalize-RoomText $Value
  if (-not $target -or -not $normalized) { return $false }
  if ($normalized -eq $target) { return $true }
  foreach ($line in (($Value -as [string]) -split "`r?`n")) {
    if ((Normalize-RoomText $line) -eq $target) { return $true }
  }
  if ($target.Length -ge 5 -and $normalized.Length -ge 5 -and (Get-RoomTextSimilarity -Value $Value -Room $Room) -ge 0.8) {
    return $true
  }
  if (-not $normalized.StartsWith($target)) { return $false }
  $rest = $normalized.Substring($target.Length)
  if (-not $rest) { return $true }
  $fullWidthLeftParen = [string]([char]0xFF08)
  $yesterday = [string]([char]0x6628) + [string]([char]0x5929)
  foreach ($prefix in @('[', '(', $fullWidthLeftParen, '@', $yesterday, 'Yesterday')) {
    if ($rest.StartsWith($prefix)) { return $true }
  }
  return ($rest[0] -match '\d')
}

function Test-RoomSearchTextMatches {
  param([string]$Value, [string]$Room)
  if (Test-RoomTextMatches -Value $Value -Room $Room) { return $true }
  $target = Normalize-RoomText $Room
  $normalized = Normalize-RoomText $Value
  if ($target.Length -lt 3 -or $normalized.Length -lt 3) { return $false }
  if ($target.StartsWith($normalized) -or $normalized.StartsWith($target)) { return $true }
  return (Get-RoomTextSimilarity -Value $Value -Room $Room) -ge 0.8
}

function Get-LeftPaneMaxX {
  param([hashtable]$Rect)
  return [int]($Rect.Left + [Math]::Min(360, [Math]::Max(280, $Rect.Width * 0.36)))
}

function Get-SearchResultX {
  param([hashtable]$Rect)
  return [int]($Rect.Left + [Math]::Min(210, [Math]::Max(145, $Rect.Width * 0.18)))
}

function Get-AutomationElements {
  param([System.Diagnostics.Process]$Process)
  $uiaType = [type]::GetType('System.Windows.Automation.AutomationElement, UIAutomationClient')
  if (-not $uiaType) { return @() }
  try {
    $handle = Get-WeChatMainWindowHandle -Process $Process
    if ($handle -eq [IntPtr]::Zero) { return @() }
    $root = [System.Windows.Automation.AutomationElement]::FromHandle($handle)
    if (-not $root) { return @() }
    $condition = [System.Windows.Automation.Condition]::TrueCondition
    $elements = $root.FindAll([System.Windows.Automation.TreeScope]::Descendants, $condition)
    $items = New-Object System.Collections.Generic.List[object]
    $limit = [Math]::Min($elements.Count, 2600)
    for ($i = 0; $i -lt $limit; $i += 1) {
      $element = $elements.Item($i)
      $name = ''
      $controlType = ''
      $automationId = ''
      $isKeyboardFocusable = $false
      try { $name = $element.Current.Name } catch {}
      try { $controlType = $element.Current.ControlType.ProgrammaticName } catch {}
      try { $automationId = $element.Current.AutomationId } catch {}
      try { $isKeyboardFocusable = [bool]$element.Current.IsKeyboardFocusable } catch {}
      if ([string]::IsNullOrWhiteSpace($name) -and $controlType -notmatch 'Edit|Document') { continue }
      $bounds = $null
      try { $bounds = $element.Current.BoundingRectangle } catch {}
      if ($null -eq $bounds -or $bounds.Width -le 0 -or $bounds.Height -le 0) { continue }
      $items.Add([pscustomobject]@{
        Name = $name
        ControlType = $controlType
        AutomationId = $automationId
        IsKeyboardFocusable = $isKeyboardFocusable
        X = [double]($bounds.X + ($bounds.Width / 2))
        Y = [double]($bounds.Y + ($bounds.Height / 2))
        Left = [double]$bounds.X
        Top = [double]$bounds.Y
        Width = [double]$bounds.Width
        Height = [double]$bounds.Height
      })
    }
    return $items
  } catch {
    Write-AutoLog "UIAutomation read failed: $($_.Exception.Message)"
    return @()
  }
}

function Test-ActiveRoom {
  param([System.Diagnostics.Process]$Process, [hashtable]$Rect, [string]$Room)
  try { $Process.Refresh() } catch {}
  if (Test-RoomTextMatches -Value $Process.MainWindowTitle -Room $Room) {
    Write-AutoLog "verified active room by window title room=$Room title=$($Process.MainWindowTitle)"
    return $true
  }

  $minX = $Rect.Left + [Math]::Min(260, [Math]::Max(185, $Rect.Width * 0.26))
  $maxY = $Rect.Top + 150
  $matches = New-Object System.Collections.Generic.List[string]
  foreach ($item in (Get-AutomationElements -Process $Process)) {
    if (-not (Test-RoomTextMatches -Value $item.Name -Room $Room)) { continue }
    if ($item.X -gt $minX -and $item.X -le $Rect.Right -and $item.Y -ge $Rect.Top -and $item.Y -le $maxY) {
      Write-AutoLog "verified active room by UIAutomation header room=$Room text=$($item.Name) point=$([int]$item.X),$([int]$item.Y)"
      return $true
    }
    if ($matches.Count -lt 5) {
      $matches.Add("$($item.Name)@$([int]$item.X),$([int]$item.Y)")
    }
  }
  if ($matches.Count -gt 0) {
    Write-AutoLog "active room text candidates outside header room=$Room candidates=$($matches -join ';')"
  }
  return $false
}

function Wait-ActiveRoom {
  param([System.Diagnostics.Process]$Process, [hashtable]$Rect, [string]$Room, [int]$Attempts = 3)
  for ($attempt = 1; $attempt -le $Attempts; $attempt += 1) {
    if (Test-ActiveRoom -Process $Process -Rect $Rect -Room $Room) { return $true }
    Write-AutoLog "active room verify attempt $attempt failed room=$Room"
    Start-Sleep -Milliseconds 420
  }
  return $false
}

function Test-UsefulSearchRowText {
  param([string]$Text)
  $trimmed = ($Text -as [string]).Trim()
  if ([string]::IsNullOrWhiteSpace($trimmed)) { return $false }
  $compact = Normalize-RoomText $trimmed
  if ([string]::IsNullOrWhiteSpace($compact)) { return $false }
  $searchText = [string]([char]0x641C) + [string]([char]0x7D22)
  $searchWebText = [string]([char]0x641C) + [string]([char]0x4E00) + [string]([char]0x641C)
  $multiplySign = [string]([char]0x00D7)
  if (@('Q', $searchText, $searchWebText, 'x', 'X', $multiplySign, 'AI') -contains $trimmed) { return $false }
  if (@('Q', $searchText, $searchWebText, 'x', 'X', $multiplySign, 'AI') -contains $compact) { return $false }
  if ($trimmed -match '^\d{1,2}:\d{2}$') { return $false }
  if ($trimmed -match '^\d+$') { return $false }
  return $true
}

function Get-SearchResultRowHits {
  param([System.Diagnostics.Process]$Process, [hashtable]$Rect)
  $leftMax = Get-LeftPaneMaxX -Rect $Rect
  $minX = $Rect.Left + 45
  $maxX = $leftMax + 220
  $minY = $Rect.Top + 82
  $maxY = $Rect.Top + [Math]::Min(360, $Rect.Height - 54)
  $items = New-Object System.Collections.Generic.List[object]
  foreach ($item in (Get-AutomationElements -Process $Process)) {
    if ($item.X -lt $minX -or $item.X -gt $maxX) { continue }
    if ($item.Y -lt $minY -or $item.Y -gt $maxY) { continue }
    if (-not (Test-UsefulSearchRowText -Text $item.Name)) { continue }
    $items.Add($item)
  }

  $sorted = @($items | Sort-Object @{ Expression = 'Y'; Ascending = $true }, @{ Expression = 'X'; Ascending = $true })
  $rows = New-Object System.Collections.Generic.List[object]
  foreach ($item in $sorted) {
    if ($rows.Count -gt 0) {
      $last = $rows[$rows.Count - 1]
      $sumY = 0.0
      foreach ($entry in $last) { $sumY += [double]$entry.Y }
      $centerY = $sumY / [Math]::Max(1, $last.Count)
      if ([Math]::Abs([double]$item.Y - $centerY) -le 28) {
        $last.Add($item)
        continue
      }
    }
    $row = New-Object System.Collections.Generic.List[object]
    $row.Add($item)
    $rows.Add($row)
  }

  $hits = New-Object System.Collections.Generic.List[object]
  $rowNumber = 1
  foreach ($row in $rows) {
    $rowItems = @($row | Sort-Object @{ Expression = 'X'; Ascending = $true })
    $texts = @()
    foreach ($entry in $rowItems) { $texts += $entry.Name }
    $clickItem = $null
    foreach ($entry in $rowItems) {
      if ($entry.X -ge ($Rect.Left + 115)) {
        $clickItem = $entry
        break
      }
    }
    if ($null -eq $clickItem -and $rowItems.Count -gt 0) { $clickItem = $rowItems[0] }
    if ($null -ne $clickItem) {
      $hit = [pscustomobject]@{
        Row = $rowNumber
        Text = ($texts -join ' | ')
        X = [int]$clickItem.X
        Y = [int]$clickItem.Y
      }
      $hits.Add($hit)
      Write-AutoLog "UIAutomation search result row $($hit.Row) text=$($hit.Text) point=$($hit.X),$($hit.Y)"
    }
    $rowNumber += 1
  }
  if ($hits.Count -eq 0) {
    Write-AutoLog 'UIAutomation search result row hits none'
  }
  return $hits
}

function Get-SearchResultCandidates {
  param([System.Diagnostics.Process]$Process, [hashtable]$Rect, [string]$Room = '')
  $searchX = Get-SearchResultX -Rect $Rect
  $searchCenterY = $Rect.Top + 55
  $maxY = $Rect.Top + [Math]::Min(300, [Math]::Max(225, $Rect.Height - 64))
  $candidates = New-Object System.Collections.Generic.List[object]
  $seen = @{}

  function Add-Candidate {
    param([int]$X, [int]$Y, [string]$Reason, [double]$Score = 0.0, [string]$Text = '')
    if ($Y -gt $maxY) { $Y = [int]$maxY }
    $key = "$X,$Y"
    if ($seen.ContainsKey($key)) { return }
    $seen[$key] = $true
    $candidates.Add([pscustomobject]@{ X = $X; Y = $Y; Reason = $Reason; Score = $Score; Text = $Text })
  }

  $rowHits = Get-SearchResultRowHits -Process $Process -Rect $Rect
  foreach ($rowHit in $rowHits) {
    $score = 20.0
    $reason = "uia-row-$($rowHit.Row)-$($rowHit.Text)"
    if (-not [string]::IsNullOrWhiteSpace($Room)) {
      $similarity = Get-RoomTextSimilarity -Value $rowHit.Text -Room $Room
      if (Test-RoomSearchTextMatches -Value $rowHit.Text -Room $Room) {
        $score += 1000.0 + ($similarity * 100.0)
        $reason = "uia-room-match-$($rowHit.Text)"
      } else {
        $score += ($similarity * 100.0)
      }
    }
    $score -= ([double]$rowHit.Y / 10000.0)
    Add-Candidate -X ([int]$rowHit.X) -Y ([int]$rowHit.Y) -Reason $reason -Score $score -Text $rowHit.Text
  }

  $firstFallbackY = [int]($searchCenterY + [Math]::Min(72, [Math]::Max(54, $Rect.Height * 0.07)))
  $fallbackStep = [int][Math]::Min(82, [Math]::Max(48, $Rect.Height * 0.075))
  $fallbackY = $firstFallbackY
  while ($fallbackY -le $maxY) {
    $fallbackScore = 1.0 - (($fallbackY - $firstFallbackY) / [Math]::Max(1.0, ($maxY - $firstFallbackY + 1.0)))
    Add-Candidate -X ([int]$searchX) -Y ([int]$fallbackY) -Reason "geometry-visible-result" -Score $fallbackScore
    $fallbackY += $fallbackStep
  }

  $ordered = @($candidates | Sort-Object @{ Expression = 'Score'; Descending = $true }, @{ Expression = 'Y'; Ascending = $true })
  $summaryParts = @()
  foreach ($candidate in $ordered) {
    $summaryParts += "$($candidate.Reason) score=$([Math]::Round([double]$candidate.Score, 2)) point=$($candidate.X),$($candidate.Y)"
  }
  Write-AutoLog "search result probe candidates $($summaryParts -join ';')"

  return $ordered
}

function Get-SearchCandidateKey {
  param([object]$Candidate)
  $text = Normalize-RoomText ($Candidate.Text -as [string])
  if ($text) { return "text:$text" }
  return "point:$($Candidate.X),$($Candidate.Y)"
}

function Select-SearchCandidate {
  param([object[]]$Candidates, [hashtable]$Tried)
  foreach ($candidate in $Candidates) {
    $key = Get-SearchCandidateKey -Candidate $candidate
    if (-not $Tried.ContainsKey($key)) { return $candidate }
  }
  return @($Candidates | Select-Object -First 1)[0]
}

function Click-SearchResult {
  param([System.Diagnostics.Process]$Process, [hashtable]$Rect, [string]$Room, [hashtable]$Tried)
  $candidates = Get-SearchResultCandidates -Process $Process -Rect $Rect -Room $Room
  if ($candidates.Count -eq 0) {
    throw "No selectable WeChat search result candidates for room: $Room"
  }
  $candidate = Select-SearchCandidate -Candidates $candidates -Tried $Tried
  $candidateKey = Get-SearchCandidateKey -Candidate $candidate
  $Tried[$candidateKey] = $true
  Write-AutoLog "click search result candidate room=$Room key=$candidateKey reason=$($candidate.Reason) score=$($candidate.Score) point=$($candidate.X),$($candidate.Y)"
  Click-Point -X $candidate.X -Y $candidate.Y -Name "search result candidate"
  Start-Sleep -Milliseconds 900
  if (Wait-ActiveRoom -Process $Process -Rect $Rect -Room $Room -Attempts 3) {
    return $candidate.Reason
  }
  throw "WeChat search probe rows were not confirmed for room: $Room"
}

function Focus-SearchField {
  param([hashtable]$Rect)
  $searchX = $Rect.Left + 240
  $searchY = $Rect.Top + 55
  Click-Point -X $searchX -Y $searchY -Name 'search'
}

function Select-ChatsTab {
  param([hashtable]$Rect)
  $chatX = $Rect.Left + 58
  $chatY = $Rect.Top + 142
  Click-Point -X $chatX -Y $chatY -Name 'message home tab'
}

function Reset-ToMessageHomeForSearch {
  param([hashtable]$Rect)
  Write-AutoLog 'reset to message home before search'
  Assert-WeChatForeground -Context 'reset-search'
  Send-WeChatKeys -Keys '{ESC}' -Context 'reset-search-before-tab' -AfterDelayMs 180
  Select-ChatsTab -Rect $Rect
  Start-Sleep -Milliseconds 220
  Send-WeChatKeys -Keys '{ESC}' -Context 'reset-search-after-tab' -AfterDelayMs 160
}

function Open-Room {
  param([System.Diagnostics.Process]$Process, [hashtable]$Rect, [string]$Room)
  Write-AutoLog "rpa step=open-room start room=$Room rect=$($Rect.Left),$($Rect.Top),$($Rect.Width)x$($Rect.Height)"
  if (Wait-ActiveRoom -Process $Process -Rect $Rect -Room $Room -Attempts 2) {
    Write-AutoLog "active room already open; skip search room=$Room"
    return 'already-open'
  }

  $triedCandidates = @{}
  for ($attempt = 1; $attempt -le 3; $attempt += 1) {
    Write-AutoLog "rpa step=search-room attempt=$attempt/3 room=$Room"
    Reset-ToMessageHomeForSearch -Rect $Rect
    Focus-SearchField -Rect $Rect
    Clear-Input
    Set-ClipboardTextSafe -Text $Room
    Paste-Clipboard
    Start-Sleep -Milliseconds (850 + ($attempt * 250))
    try {
      $selection = Click-SearchResult -Process $Process -Rect $Rect -Room $Room -Tried $triedCandidates
      if (Wait-ActiveRoom -Process $Process -Rect $Rect -Room $Room -Attempts 3) {
        Send-WeChatKeys -Keys '{ESC}' -Context 'search-room-dismiss' -AfterDelayMs 180
        Write-AutoLog "search room verified room=$Room attempt=$attempt selection=$selection"
        return $selection
      }
    } catch {
      Write-AutoLog "search room attempt $attempt/3 failed room=$Room error=$($_.Exception.Message)"
      Reset-ToMessageHomeForSearch -Rect $Rect
    }
  }

  throw "WeChat search result was not confirmed for room: $Room"
}

function Assert-TargetRoom {
  param([System.Diagnostics.Process]$Process, [hashtable]$Rect, [string]$Room, [string]$Context)
  if ([string]::IsNullOrWhiteSpace($Room)) { return }
  Assert-WeChatForeground -Process $Process -Context "verify-room-$Context"
  if (Wait-ActiveRoom -Process $Process -Rect $Rect -Room $Room -Attempts 3) {
    Write-AutoLog "rpa step=verify-room context=$Context room=$Room ok"
    return
  }
  throw "Target WeChat room was not verified before ${Context}: $Room. Stop to avoid sending to the wrong chat."
}

function Get-MessageInputPoint {
  param([System.Diagnostics.Process]$Process, [hashtable]$Rect)
  if (-not $Process) { return $null }
  $minX = $Rect.Left + [Math]::Min(260, [Math]::Max(185, $Rect.Width * 0.26))
  $minY = $Rect.Top + ($Rect.Height * 0.68)
  $maxY = $Rect.Bottom - 18
  $candidates = New-Object System.Collections.Generic.List[object]

  foreach ($item in (Get-AutomationElements -Process $Process)) {
    if ($item.X -le $minX -or $item.X -gt ($Rect.Right - 16)) { continue }
    if ($item.Y -lt $minY -or $item.Y -gt $maxY) { continue }
    if ($item.Width -lt 90 -or $item.Height -lt 20) { continue }
    if (($item.Name -as [string]) -match '\u641C\u7D22|Search') { continue }
    $looksEditable = (($item.ControlType -as [string]) -match 'Edit|Document') -or [bool]$item.IsKeyboardFocusable
    if (-not $looksEditable) { continue }
    $clickX = [int][Math]::Min($item.Left + $item.Width - 42, $item.Left + [Math]::Min(92, [Math]::Max(56, $item.Width * 0.14)))
    $candidates.Add([pscustomobject]@{
      X = $clickX
      Y = [int]$item.Y
      Area = [double]($item.Width * $item.Height)
      ControlType = $item.ControlType
      Name = $item.Name
      Bounds = "$([int]$item.Left),$([int]$item.Top),$([int]$item.Width)x$([int]$item.Height)"
    })
  }

  $best = @($candidates | Sort-Object @{ Expression = 'Area'; Descending = $true } | Select-Object -First 1)
  if ($best.Count -gt 0) {
    Write-AutoLog "message input UIAutomation point controlType=$($best[0].ControlType) name=$($best[0].Name) point=$($best[0].X),$($best[0].Y) bounds=$($best[0].Bounds)"
    return $best[0]
  }
  Write-AutoLog 'message input UIAutomation point not found'
  return $null
}

function Focus-MessageInput {
  param([hashtable]$Rect, [System.Diagnostics.Process]$Process = $null)
  Write-AutoLog "focus message input start rect=$($Rect.Left),$($Rect.Top),$($Rect.Width)x$($Rect.Height)"
  $detected = Get-MessageInputPoint -Process $Process -Rect $Rect
  if ($detected) {
    Click-Point -X $detected.X -Y $detected.Y -Name 'message input detected'
    return
  }
  $leftPaneMax = $Rect.Left + [Math]::Min(260, [Math]::Max(185, $Rect.Width * 0.26))
  $inputX = [int][Math]::Min($Rect.Right - 110, [Math]::Max($leftPaneMax + 42, $leftPaneMax + 72))
  $inputY = [int]($Rect.Bottom - 78)
  Write-AutoLog "message input fallback point=$inputX,$inputY"
  Click-Point -X $inputX -Y $inputY -Name 'message input'
}

function Move-CursorToInputEnd {
  param([hashtable]$Rect, [System.Diagnostics.Process]$Process = $null)
  Focus-MessageInput -Rect $Rect -Process $Process
  Send-WeChatKeys -Keys '^{END}' -Context 'move-input-end' -AfterDelayMs 160
}

function Get-DraftText {
  param([hashtable]$Rect, [System.Diagnostics.Process]$Process = $null, [string]$Context)
  $sentinel = '__MAO_EMPTY_DRAFT_CHECK__' + [guid]::NewGuid().ToString() + '__'
  Focus-MessageInput -Rect $Rect -Process $Process
  Send-WeChatKeys -Keys '^a' -Context "$Context-select-draft" -AfterDelayMs 100
  [System.Windows.Forms.Clipboard]::SetText($sentinel)
  Start-Sleep -Milliseconds 80
  Send-WeChatKeys -Keys '^c' -Context "$Context-copy-draft" -AfterDelayMs 140
  $copied = ''
  try { $copied = [System.Windows.Forms.Clipboard]::GetText() } catch {}
  $draft = if ($copied -eq $sentinel) { '' } else { $copied }
  $preview = ($draft -replace "`r", '\r' -replace "`n", '\n')
  if ($preview.Length -gt 80) { $preview = $preview.Substring(0, 80) + '...' }
  Write-AutoLog "$Context draft text length=$($draft.Length) preview=$preview"
  Send-WeChatKeys -Keys '^{END}' -Context "$Context-restore-caret" -AfterDelayMs 120
  return $draft
}

function Test-DraftContainsBody {
  param([string]$Draft, [string]$Body)
  $compactBody = (($Body -as [string]) -replace '\s+', '')
  if ([string]::IsNullOrWhiteSpace($compactBody)) { return $true }
  $compactDraft = (($Draft -as [string]) -replace '\s+', '')
  if ($compactDraft.Contains($compactBody)) { return $true }
  $prefixLength = [Math]::Min(18, $compactBody.Length)
  if ($prefixLength -lt 6) { return $false }
  return $compactDraft.Contains($compactBody.Substring(0, $prefixLength))
}

function Test-DraftContainsToken {
  param([string]$Draft, [string]$Token)
  $target = Normalize-RoomText $Token
  $draftText = Normalize-RoomText $Draft
  if ([string]::IsNullOrWhiteSpace($target)) { return $true }
  if ([string]::IsNullOrWhiteSpace($draftText)) { return $false }
  if ($draftText.Contains($target)) { return $true }
  if ($target.Length -ge 3 -and (Get-RoomTextSimilarity -Value $Draft -Room $Token) -ge 0.8) { return $true }
  return $false
}

function Mention-Members {
  param([string[]]$Mentions, [hashtable]$Rect, [System.Diagnostics.Process]$Process = $null, [string]$Room = '')
  foreach ($name in $Mentions) {
    Assert-TargetRoom -Process $Process -Rect $Rect -Room $Room -Context "mention-$name"
    Assert-WeChatForeground -Context 'mention'
    Send-WeChatKeys -Keys '@' -Context 'mention-open' -AfterDelayMs 220
    Set-ClipboardTextSafe -Text $name
    Paste-Clipboard
    Start-Sleep -Milliseconds 500
    Send-WeChatKeys -Keys '{ENTER}' -Context 'mention-select'
    Write-AutoLog "selected mention: $name"
    Start-Sleep -Milliseconds 350
    $draftAfterMention = Get-DraftText -Rect $Rect -Process $Process -Context "after mention $name"
    if (-not (Test-DraftContainsToken -Draft $draftAfterMention -Token $name)) {
      $preview = (($draftAfterMention -as [string]) -replace "`r", '\r' -replace "`n", '\n')
      if ($preview.Length -gt 36) { $preview = $preview.Substring(0, 36) + '...' }
      throw "WeChat mention was not confirmed in draft for member: $name; draft=$preview"
    }
  }
}

function Press-SendEnter {
  Assert-WeChatForeground -Context 'send-enter'
  Send-WeChatKeys -Keys '{ENTER}' -Context 'send-enter'
  Write-AutoLog 'pressed Enter for send'
  Start-Sleep -Milliseconds 500
}

function Send-AndVerify {
  param([hashtable]$Rect, [System.Diagnostics.Process]$Process = $null)
  Press-SendEnter
  Start-Sleep -Milliseconds 500
  $remaining = Get-DraftText -Rect $Rect -Process $Process -Context 'after send attempt 1'
  if ([string]::IsNullOrWhiteSpace($remaining)) {
    Write-AutoLog 'send verified draft cleared'
    return
  }

  Write-AutoLog "send attempt 1 left non-empty draft length=$($remaining.Length); retry Enter once"
  Press-SendEnter
  Start-Sleep -Milliseconds 600
  $remaining = Get-DraftText -Rect $Rect -Process $Process -Context 'after send attempt 2'
  if ([string]::IsNullOrWhiteSpace($remaining)) {
    Write-AutoLog 'send verified draft cleared after retry'
    return
  }
  $preview = ($remaining -replace "`r", '\r' -replace "`n", '\n')
  if ($preview.Length -gt 36) { $preview = $preview.Substring(0, 36) + '...' }
  throw "WeChat message was not confirmed sent; draft remains ($($remaining.Length) chars): $preview"
}

$options = Parse-Options
Write-AutoLog "started args=$($RestArgs -join ' ')"
Write-AutoLog "runtime cwd=$(Get-Location) logPath=$LogPath user=$([Environment]::UserName) psVersion=$($PSVersionTable.PSVersion)"
Write-AutoLog "parsed options roomSet=$([bool]$options.Room) mentions=$($options.Mentions.Count) images=$($options.Images.Count) send=$($options.Send) checkPermission=$($options.CheckPermission) keyboard=$($options.KeyboardTest) keyboardEnter=$($options.KeyboardEnterTest) openRetry=$($options.OpenRetryTest) pressReturnOnly=$($options.PressReturnOnly) selectMethod=$($options.SelectMethod)"

if ($options.CheckPermission) {
  Write-AutoLog 'permission check ok on Windows'
  Emit-Json @{ ok = $true; platform = 'win32'; trusted = $true; permissionRequired = $false; logPath = $LogPath }
  exit 0
}

if ($options.OpenRetryTest -and -not $options.Room) {
  throw 'Missing --room.'
}

$session = Activate-WeChat
$rect = $session.Rect
$selection = ''
if ($options.Room) {
  $selection = Open-Room -Process $session.Process -Rect $rect -Room $options.Room
  $session = Activate-WeChat
  $rect = $session.Rect
  Assert-TargetRoom -Process $session.Process -Rect $rect -Room $options.Room -Context 'open-room-complete'
}

if ($options.OpenRetryTest) {
  Emit-Json @{
    ok = $true
    platform = 'win32'
    action = 'open-retry-test'
    roomName = $options.Room
    selection = $selection
    logPath = $LogPath
  }
  exit 0
}

Focus-MessageInput -Rect $rect -Process $session.Process

if ($options.PressReturnOnly) {
  Press-SendEnter
  Emit-Json @{ ok = $true; platform = 'win32'; action = 'press-return-only'; logPath = $LogPath }
  exit 0
}

if ($options.KeyboardTest -or $options.KeyboardEnterTest) {
  $action = if ($options.KeyboardEnterTest) { 'keyboard-enter-test' } else { 'keyboard-test' }
  $text = 'keyboard-test-' + (Get-Date -Format 'HHmmss')
  Write-AutoLog "$action paste start text=$text"
  Set-ClipboardTextSafe -Text $text
  Paste-Clipboard
  Start-Sleep -Milliseconds 250
  $draftAfterPaste = Get-DraftText -Rect $rect -Process $session.Process -Context "$action after paste"
  if (-not (($draftAfterPaste -as [string]).Contains($text))) {
    $preview = (($draftAfterPaste -as [string]) -replace "`r", '\r' -replace "`n", '\n')
    if ($preview.Length -gt 36) { $preview = $preview.Substring(0, 36) + '...' }
    throw "Keyboard test did not paste expected text; draft length=$($draftAfterPaste.Length) preview=$preview"
  }
  Write-AutoLog "$action paste verified draft length=$($draftAfterPaste.Length)"
  if ($options.KeyboardEnterTest) {
    Write-AutoLog "$action send enter start"
    Press-SendEnter
    Start-Sleep -Milliseconds 600
    $remaining = Get-DraftText -Rect $rect -Process $session.Process -Context "$action after enter"
    if (-not [string]::IsNullOrWhiteSpace($remaining)) {
      $preview = ($remaining -replace "`r", '\r' -replace "`n", '\n')
      if ($preview.Length -gt 36) { $preview = $preview.Substring(0, 36) + '...' }
      throw "Enter did not send the message; draft remains ($($remaining.Length) chars): $preview. Check whether WeChat is configured to send with Ctrl+Enter."
    }
    Write-AutoLog "$action send verified draft cleared"
  }
  Emit-Json @{ ok = $true; platform = 'win32'; text = $text; pressEnter = [bool]$options.KeyboardEnterTest; logPath = $LogPath }
  exit 0
}

if (-not $options.Room) { throw 'Missing --room.' }
$pastedImages = 0
$hasTextMessage = ($options.Mentions.Count -gt 0) -or (-not [string]::IsNullOrWhiteSpace($options.Text))
Assert-TargetRoom -Process $session.Process -Rect $rect -Room $options.Room -Context 'compose-start'
Focus-MessageInput -Rect $rect -Process $session.Process
Clear-Input

if ($hasTextMessage) {
  Write-AutoLog "rpa step=compose-text mentions=$($options.Mentions.Count) textLength=$($options.Text.Length)"
  Mention-Members -Mentions $options.Mentions.ToArray() -Rect $rect -Process $session.Process -Room $options.Room
  if ($options.Text) {
    Assert-TargetRoom -Process $session.Process -Rect $rect -Room $options.Room -Context 'body-paste'
    Move-CursorToInputEnd -Rect $rect -Process $session.Process
    $prefix = if ($options.Mentions.Count -gt 0) { "`r`n" } else { "" }
    Set-ClipboardTextSafe -Text ($prefix + $options.Text)
    Paste-Clipboard
    Start-Sleep -Milliseconds 500
    $draftAfterBody = Get-DraftText -Rect $rect -Process $session.Process -Context 'after body paste'
    if (-not (Test-DraftContainsBody -Draft $draftAfterBody -Body $options.Text)) {
      Write-AutoLog 'body text missing after paste; retry once'
      Move-CursorToInputEnd -Rect $rect -Process $session.Process
      Set-ClipboardTextSafe -Text ($prefix + $options.Text)
      Paste-Clipboard
      Start-Sleep -Milliseconds 500
      $draftAfterBody = Get-DraftText -Rect $rect -Process $session.Process -Context 'after body paste retry'
    }
    if (-not (Test-DraftContainsBody -Draft $draftAfterBody -Body $options.Text)) {
      throw 'WeChat body text was not written into the input box; stop to avoid sending only mentions.'
    }
    Move-CursorToInputEnd -Rect $rect -Process $session.Process
  }
} else {
  Write-AutoLog 'skip text message because mention/body are empty'
}

if (-not $options.Send -and $options.Images.Count -gt 0) {
  Assert-TargetRoom -Process $session.Process -Rect $rect -Room $options.Room -Context 'dry-run-images'
  $pastedImages = Set-ClipboardFilesSafe -Paths $options.Images.ToArray()
  if ($pastedImages -gt 0) {
    Paste-Clipboard
    Start-Sleep -Milliseconds 1000
  }
}

if ($options.Send) {
  if ($hasTextMessage) {
    Assert-TargetRoom -Process $session.Process -Rect $rect -Room $options.Room -Context 'send-text'
    Write-AutoLog 'rpa step=send-text'
    Send-AndVerify -Rect $rect -Process $session.Process
    Start-Sleep -Milliseconds 700
  }

  if ($options.Images.Count -gt 0) {
    Assert-TargetRoom -Process $session.Process -Rect $rect -Room $options.Room -Context 'send-images'
    Focus-MessageInput -Rect $rect -Process $session.Process
    Clear-Input
    Write-AutoLog "rpa step=send-images count=$($options.Images.Count)"
    $pastedImages = Set-ClipboardFilesSafe -Paths $options.Images.ToArray()
    if ($pastedImages -gt 0) {
      Paste-Clipboard
      Start-Sleep -Milliseconds 1000
      Assert-TargetRoom -Process $session.Process -Rect $rect -Room $options.Room -Context 'send-images-before-enter'
      Send-AndVerify -Rect $rect -Process $session.Process
    } else {
      Write-AutoLog 'no image files pasted'
    }
  }

  if (-not $hasTextMessage -and $pastedImages -le 0) {
    Write-AutoLog 'nothing to send: no text and no pasted images'
  }
}

Emit-Json @{
  ok = $true
  platform = 'win32'
  roomName = $options.Room
  mentions = $options.Mentions.ToArray()
  sent = [bool]$options.Send
  requestedImages = $options.Images.Count
  pastedImages = $pastedImages
  selection = $selection
  logPath = $LogPath
}
